//Code by Shaun Dulley 2019
//Code created by referncing https://stackoverflow.com/questions/20244566/most-isolated-point-on-2d-map-algorithm

#include <iostream>
#include <string>
#include <fstream>
#include <algorithm> 
#include <math.h>
#include <vector>

//Set variables
int count;

//Main function
int main()
{
	using namespace std;

	string most_isolated;

	string filename;

	int rows;

	//Ask user input for filename

	cout << "please insert 1 for problem_small, 2 for problem_big or any other key to close the program: ";
	cin >> filename;

	//Set number of rows in 2d vector dependent on number of items in file 
	if (filename == "1") {
		filename = "problem_small.txt";
		rows = 7;

	}
	else if (filename == "2") {
		filename == "problem_big.txt";
		rows = 100001;
	}
	else {

		exit(1);
	}

	



	//Open file stream
	ifstream file(filename);

	cout << "reading file\n";

	if (file.is_open())
	{
		//if file is open set vectors for file data
		vector <string> name(rows);
		vector <vector<double> > myArray(rows, vector< double >(2));

		//set data in vectors
		for (int count = 0; count < rows; count++)
		{
			file >> name[count];
			file >> myArray[count][0];
			file >> myArray[count][1];

		}
		cout << "file read succesfully\n";

		cout << "Calculating most isolated point\n";



		//set vaiarables for calculation of most isolated point
		double shortest_distance_to_most_isolated_point = 0;
		double distance_to_nearest_neighbour = 10000000000000;
		double distance;
		int i = 0;
		int j = 1;

		//set loop to run for every row
		while (i != rows) {

			//find the hypot of two points
			if (j != rows) {

				distance = hypot((myArray[j][0] - myArray[i][0]), (myArray[j][1] - myArray[i][1]));

				//compare hypot to the distance to the currently anaylsed points nearest neighbor, if it is less make the distance equal to the hypot
				if (distance < distance_to_nearest_neighbour) {
					distance_to_nearest_neighbour = distance;


				}
				//increment j so that the distance between the currently anaylsed point can be compared with every point proceeding it in our vector
				j++;
			}

			else {

				//compare the ditanc eof the nearerst neighbor of the point currently anaylsing to the shortest distance of what is currently the most isolated point anaylsed.
				//If it is greater than this value, replace it and name the point currently being analysed the most isolated point
				if (distance_to_nearest_neighbour > shortest_distance_to_most_isolated_point) {
					shortest_distance_to_most_isolated_point = distance_to_nearest_neighbour;
					most_isolated = name[i];
				}
				//Increment i and reset other variables for the next pass in the loop
				i++;
				j = i + 1;
				distance_to_nearest_neighbour = 10000000000000;
			}
		}

		//output the most isolated point
		cout << "The most isolated point is: ";
		cout << most_isolated;
		cout << "\n";

	}
	
	string key;

	cout<<"Press any key to exit";
	cout << "\n";

	cin >> key;
}


	